#You may use import as below.
#import math

def solution(num):
    # Write code here.
    answer = 0
    return answer


#The following is code to output testcase.
num = 9949999;
ret = solution(num)

#Press Run button to receive output. 
print("Solution: return value of the function is", ret, ".")