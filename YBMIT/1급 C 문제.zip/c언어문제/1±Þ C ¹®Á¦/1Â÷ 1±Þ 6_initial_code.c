// You may use include as below.
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(char* pos) {
    // Write code here.
    int answer = 0;
    return answer;
}

// The following is main function to output testcase.
int main() {
    char* pos = "A7";
    int ret = solution(pos);

    // Press Run button to receive output. 
    printf("Solution: return value of the function is %d .\n", ret);
}