#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(int number, int target) {
    int answer = 0;

    int q[10001], visited[10001];
    int head = 0, tail = 0;
    q[tail++] = number;
    visited[number] = 1;

    while(head <= tail) {
        int x = q[head++];

        if(x == target)
            break;

        if(x+1 <= 10000 && visited[x+1] == 0) {
            visited[x+1] = visited[x]+1;
            q[tail++] = x+1;
        }
        if(x-1 >= 0 && visited[x-1] == 0) {
            visited[x-1] = visited[x]+1;
            q[tail++] = x-1;
        }
        if(2*x <= 10000 && visited[2*x] == 0) {
            visited[2*x] = visited[x]+1;
            q[tail++] = 2*x;
        }
    }

    answer = visited[target]-1;
    return answer;
}