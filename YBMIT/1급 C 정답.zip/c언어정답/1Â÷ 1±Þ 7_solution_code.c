#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int* solution(int arrA[], int arrA_len, int arrB[], int arrB_len) {
    int arrA_idx = 0, arrB_idx = 0;
    int* answer = (int*)malloc(sizeof(int)*(arrA_len + arrB_len));
    int answer_idx = 0;
    while(arrA_idx < arrA_len && arrB_idx < arrB_len){
        if(arrA[arrA_idx] < arrB[arrB_idx])
            answer[answer_idx++] = arrA[arrA_idx++];
        else
            answer[answer_idx++] = arrB[arrB_idx++];
    }
    while(arrA_idx < arrA_len)
        answer[answer_idx++] = arrA[arrA_idx++];
    while(arrB_idx < arrB_len)
        answer[answer_idx++] = arrB[arrB_idx++];
    
    return answer;
}