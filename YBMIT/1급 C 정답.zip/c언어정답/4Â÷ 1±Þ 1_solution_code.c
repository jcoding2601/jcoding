#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* vowels[5] = {"A", "E", "I", "O", "U"};
char* words[3906];
int words_n = 0;

void create_words(int lev, char* str) {
    words[words_n++] = str;
    for (int i = 0; i < 5; i++) {
        if (lev < 5) {
            char* new_str = (char*)malloc(sizeof(char)*(lev+2));
            strcpy(new_str, str);
            strcat(new_str, vowels[i]);
            create_words(lev + 1, new_str);
        }
    }
}

int solution(char* word) {
    int answer = 0;
    create_words(0, "");
    for (int i = 0; i < words_n; i++) {
        if (strcmp(word, words[i]) == 0) {
            answer = i;
            break;
        }
    }
    return answer;
}
