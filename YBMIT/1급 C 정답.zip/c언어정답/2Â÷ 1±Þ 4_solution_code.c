#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(int arr[], int arr_n, int K) {
    int n = arr_n;
    int count = 0;
    for(int i = 0; i < n; ++i)
        for(int j = i + 1; j < n; ++j)
            for(int k = j + 1; k < n; ++k)
                if((arr[i]+arr[j]+arr[k])%K == 0)
                    count += 1;
    return count;
}