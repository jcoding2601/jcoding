#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int compare(const void* a, const void* b) {
	return *(const int*)a - *(const int*)b;
}
int solution(int enemies[], int enemies_len, int armies[], int armies_len) {
	int answer = 0;

	qsort(enemies, enemies_len, sizeof(int), compare);
	qsort(armies, armies_len, sizeof(int), compare);
	int i = 0, j = 0;
	while(i < enemies_len && j < armies_len) {
		if(enemies[i] <= armies[j]) {
			answer++;
			i++;
			j++;
		} else {
			j++;
		}
	}

	return answer;
}