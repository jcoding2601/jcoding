#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

int solution(int K, int numbers[], int numbers_len, char* up_down[], int up_down_len) {
    int left = 1;
    int right = K;
    for(int i = 0; i < numbers_len; i++){
        int num = numbers[i];
        if(strcmp("UP", up_down[i]) == 0)
            left = left < num + 1 ? num + 1 : left;
        else if(strcmp("DOWN", up_down[i]) == 0)
            right = right > num - 1 ? num - 1 : right;
        else if(strcmp("RIGHT", up_down[i]) == 0)
            return 1;
    }
    return right - left + 1;
}