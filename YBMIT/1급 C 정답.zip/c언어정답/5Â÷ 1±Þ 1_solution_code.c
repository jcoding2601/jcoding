#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(int n) {
    int answer = 0;

    int *steps = (int *) malloc((n+1) * sizeof(int));
    steps[1] = 1;
    steps[2] = 2;
    steps[3] = 4;
    for(int i = 4; i <= n; i++)
		steps[i] = steps[i-1] + steps[i-2] + steps[i-3];
	answer = steps[n];

    return answer;
}