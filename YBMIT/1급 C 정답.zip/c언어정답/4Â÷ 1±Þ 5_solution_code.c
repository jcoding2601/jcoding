#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

char* reverse(char* number);

char* solution(int n) {
	char *answer;
	answer = (char*)malloc(sizeof(char) * (n+1));
	char ch;
	for(int i = 0; i < n; ++i)
	{
		ch=i%9 + 1 + '0';
		answer[i]=ch;
		answer[i+1] = '\0';
		answer = reverse(answer);
	}
	return answer;
}

char* reverse(char* number) {
	char *reverse_number;
	reverse_number = (char*)malloc(sizeof(char) * (strlen(number)+2));
	int j = 0;
	for(int i = strlen(number)-1; i >= 0;--i) {
		reverse_number[j++]=number[i];
	}
	reverse_number[j] = '\0';
	free(number);
	return reverse_number;
}