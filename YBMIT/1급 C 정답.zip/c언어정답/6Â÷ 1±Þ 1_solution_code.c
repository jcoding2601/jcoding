#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct Flower {
	int x, y, day;
} Flower;

Flower *q;
int front;
int rear;

void enqueue(int size, Flower data) {
	q[rear] = data;
	rear++;
	rear = rear % size;
}

void dequeue(int size) {
	front++;
	front = front % size;
}

int solution(int n, int garden[][n]) {
    int answer = 0;

    int dx[4] = { -1, 1, 0, 0 };
    int dy[4] = { 0, 0, -1, 1 };

    int size = n * n + 1;
    q = (Flower *) malloc(sizeof(Flower) * size);
    front = 0;
    rear = 0;
    int i, j;

    for(i = 0; i < n; i++) {
    	for(j = 0; j < n; j++) {
    		if(garden[i][j]) {
    			Flower flower = {i, j, 0};
    			enqueue(size, flower);
    		}
    	}
    }


    while(front != rear) {
    	Flower flower = q[front];
    	dequeue(size);

    	for(i = 0; i < 4; i++) {
    		int next_x = flower.x + dx[i];
    		int next_y = flower.y + dy[i];
    		int next_day = flower.day + 1;

    		if((0 <= next_x && next_x < n && 0 <= next_y && next_y < n) && !garden[next_x][next_y]) {
    			garden[next_x][next_y] = 1;
    			answer = next_day;
    			Flower flower = {next_x, next_y, next_day};
    			enqueue(size, flower);
    		}
    	}
    }

    return answer;
}