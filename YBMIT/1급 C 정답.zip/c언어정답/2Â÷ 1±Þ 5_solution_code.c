#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(int arr[], int arr_len) {
    int* dp = (int*)malloc(sizeof(int) * arr_len);
    for(int i = 0; i < arr_len; ++i)
        dp[i] = 1;
    for(int i = 1; i < arr_len; ++i)
        if(arr[i] > arr[i-1])
            dp[i] = dp[i-1] + 1;
    int answer = 0;
    for(int i = 0; i < arr_len; ++i)
        answer = answer < dp[i] ? dp[i] : answer;
    return answer;
}