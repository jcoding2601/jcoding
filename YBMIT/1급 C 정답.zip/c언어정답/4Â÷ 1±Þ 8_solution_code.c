#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int* func_a(int card[], int card_len) {
    int* card_count = (int*) malloc(sizeof(int) * 10);
    memset(card_count, 0, sizeof(int) * 10);
    for (int i = 0; i < card_len; i++) {
        card_count[card[i]]++;
    }
    return card_count;
}

int num_list[362880], num_list_len;
void func_b(int level, int max_level, int num, int current_count[], int max_count[]) {
    if (level == max_level) {
        num_list[num_list_len++] = num;
        return;
    }
    for (int i = 1; i <= 9; i++) {
        if (current_count[i] < max_count[i]) {
            current_count[i] += 1;
            func_b(level + 1, max_level, num * 10 + i, current_count, max_count);
            current_count[i] -= 1;
        }
    }
}

int func_c(int list[], int list_len, int n) {
    for (int i = 0; i < list_len; i++) {
        if (n == list[i])
            return i + 1;
    }
    return -1;
}

int solution(int card[], int card_len, int n) {
    int *card_count = func_a(card, card_len);
    int *current_count = (int*) malloc(sizeof(int) * 10);
    memset(current_count, 0, sizeof(int) * 10);
    func_b(0, card_len, 0, current_count, card_count);
    int answer = func_c(num_list, num_list_len, n);
    return answer;
}