#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

char* solution(char* phrases, int second) {
    char* answer = "";
    answer = malloc(sizeof(char) * 15);

    char* display = malloc(sizeof(char) * 100);
    strcpy(display, "______________");
    strcat(display, phrases);
    second %= 28;
    for(int i = 0; i < second; ++i)
    {
    	display[28] = display[0];
    	display[0] = ' ';
    	display = strtok(display, " ");
    }
    strncpy(answer, display, 14);
    answer[14] = NULL;
    return answer;
}