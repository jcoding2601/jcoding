#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

int* solution(char* commands) {
    int* currentPosition = (int*)malloc(sizeof(int)*2);
    currentPosition[0] = currentPosition[1] = 0;
    int length = strlen(commands);
    for(int i = 0; i < length; ++i){
        if (commands[i] == 'L')
            currentPosition[0] -= 1;
        else if(commands[i] == 'R')
            currentPosition[0] += 1;
        else if(commands[i] == 'U')
            currentPosition[1] += 1;
        else if(commands[i] == 'D')
            currentPosition[1] -= 1;
    }
    return currentPosition;
}