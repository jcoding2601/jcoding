#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(int a, int b) {
    int prime[100001] = {0};
    int chk[100001] = {0};
    int idx = 0;
    for(int i = 2; i <= 100000; i++){
        if(chk[i] == 0)
        {
            prime[idx++] = i;
            chk[i] = 1;
            for(int j = i + i; j <= 100000; j+= i)
                chk[j] = 2;
        }
    }
    
    int answer[2] = {0};
    for(int i = 0; i < idx; i++){
        int x = prime[i];
        if(x <= 1010){
            int tmp = x*x*x;
            if(a <= tmp && tmp <= b)
                answer[1]++;
        }
        if(x <= 33333){
            int tmp = x*x;
            if(a <= tmp && tmp <= b)
                answer[0]++;
        }
    }
    return answer[0] + answer[1];
}