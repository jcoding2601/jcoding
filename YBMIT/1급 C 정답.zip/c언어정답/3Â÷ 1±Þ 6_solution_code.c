#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(int n) {
    int answer = 0;
    int i, j, k;
    int prime[168];
    int prime_n = 0;
    prime[prime_n++] = 2;
    for (i = 3; i <= n; i += 2) {
        for (j = 2; j < i; j++) {
            if (i % j == 0) {
                break;
            }
        }
        if (j == i) {
            prime[prime_n++] = i;
        }
    }
    for (i = 0; i < prime_n - 2; i++) {
        for (j = i + 1; j < prime_n - 1; j++) {
            for (k = j + 1; k < prime_n; k++) {
                if (prime[i] + prime[j] + prime[k] == n) {
                    answer += 1;
                }
            }
        }
    }
    return answer;
}