#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int* solution(int N, int votes[], int votes_len) {
    int vote_counter[11] = {0};
    for (int i = 0; i < votes_len; ++i) {
        vote_counter[votes[i]] += 1;
    }
    int max_val = 0;
    int cnt = 0;
    for (int i = 1; i <= N; ++i) {
        if (max_val < vote_counter[i]) {
            max_val = vote_counter[i];
            cnt = 1;
        }
        else if(max_val == vote_counter[i]){
            cnt += 1;
        }
    }
    
    int* answer = (int*)malloc(sizeof(int)*cnt);
    for(int i = 0; i < cnt; ++i)
        answer[i] = 0;
    
    for (int i = 1, idx = 0; i <= N; ++i){
        if (vote_counter[i] == max_val) {
            answer[idx] = i;
            idx += 1;
        }
    }
    return answer;
}