#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int solution(char* s1, char* s2) {
    // 여기에 코드를 작성해주세요.
    int answer = 0;
    return answer;
}