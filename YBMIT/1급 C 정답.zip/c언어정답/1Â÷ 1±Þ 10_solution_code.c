#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int max(int a, int b){
    return a < b ? b : a;
}
int min(int a, int b){
    return a < b ? a : b;
}
int solution(int prices[], size_t prices_len) {
    int inf = 1000000001;
    int mn = inf;
    int ans = -inf;
    for(int i = 0; i < prices_len; i++){
        ans = max(ans, prices[i] - mn);
        mn = min(mn, prices[i]);
    }
    return ans;
}
