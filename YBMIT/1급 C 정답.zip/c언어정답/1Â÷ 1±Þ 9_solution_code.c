#include <stdbool.h>
#include <stdlib.h>

int func(int record){
    if(record == 0) return 1;
    else if(record == 1) return 2;
    return 0;
}

int solution(int *recordA, int recordA_len, int *recordB, int recordB_len){
    int cnt = 0;
    for(int i = 0; i < recordA_len; i++){
        if(recordA[i] == recordB[i]) continue;
        else if(recordA[i] == func(recordB[i])) cnt += 3;
        else cnt = return 0 < cnt - 1 ? cnt - 1 : 0;
    }
    return cnt;
}