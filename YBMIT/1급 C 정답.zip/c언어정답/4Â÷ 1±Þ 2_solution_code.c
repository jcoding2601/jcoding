// 다음과 같이 include를 사용할 수 있습니다.
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

const char small_letters[] = "abcdefghijklmnopqrstuvwxyz";
const char big_letters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const char numbers[][2] = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};

const char convert_small(char alphabet) {
    for (int i = 0; i < 26; i++) {
        if (big_letters[i] == alphabet) {
            return small_letters[i];
        }
    }
    return alphabet;
}

const char* int_to_string(int val) {
    return numbers[val];
}

char* solution(char* s) {
    // 여기에 코드를 작성해주세요.
    // 반환하는 문자열은 malloc을 이용해 주세요.
    int len = strlen(s);
    char* answer = (char*) malloc(sizeof(char) * (len * 2 + 1));
    answer[0] = 0;

    char boss[2] = {0};
    int cnt = 1;
    boss[0] = convert_small(s[0]);
    for (int i = 1; i < len; i++) {
        if (convert_small(s[i]) == boss[0]) {
            cnt += 1;
        }
        else {
            strcat(answer, boss);
            strcat(answer, int_to_string(cnt));
            boss[0] = convert_small(s[i]);
            cnt = 1;
        }
    }
    strcat(answer, boss);
    strcat(answer, int_to_string(cnt));
    return answer;
}