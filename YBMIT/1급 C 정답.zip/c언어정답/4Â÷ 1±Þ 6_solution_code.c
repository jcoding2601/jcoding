#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int power(int base, int exponent) {
	int val = 1;
	for (int i = 0; i < exponent; i++) {
		val *= base;
	}
	return val;
}

int* solution(int k) {
	int *answer = malloc(sizeof(int) * 5);
	int count = 0;
	int range = power(10, k);
	for (int i = range / 10; i < range; i++) {
		int current = i;
		int calculated = 0;
		while (current != 0) {
			calculated += power(current % 10, k);
			current = current / 10;
		}
		if (calculated == i) {
			answer[count] = i;
			count++;
		}
	}
	return answer;
}